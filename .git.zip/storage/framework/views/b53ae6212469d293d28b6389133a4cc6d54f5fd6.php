    <!-- veno box image pop up css link here -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/venobox.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/portfolio.css">
    <!-- portfolio filter css style link here -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/protfolio-filter.css">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/contact.css">
<style>
.form-control {
    color: #dee3e9 !important;
}
</style>

<?php $__env->startSection('frontend_content'); ?>

<?php $__env->startSection('frontend_title'); ?>
<?php echo e(('Fexdvers | Portfolio')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

    <!-- ********************************
        main wrapper start here
    ================================= -->
    <main>
    <!-- ********************************
        ::: 2.0 about banner
    ================================= -->
        <section id="portfolio-banner">
            <div class="banner-overlay">
                <div class="container">
                    <h1 class="banner-title">Our Portfolio</h2>
                        <div class="normal-btn py-3">
                            <a href="">GET STARTED <i class="fa-solid fa-angle-right"></i></a>
                        </div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 3.0 portfolio css
    ================================= -->
    <section id="portfolio" class="work pt-80">
        <div class="container">
            <div class="section-title">
                <h2>Portfolio</h2>
                <p class="mt-2 text-center">
                    Our Service Graphics & Web Design & Development , Ui/UX , Motion Graphics , Data Entry , Youtube & Digital Marketing , Video Editing , Apps Development , Animation , Others & Stationery Design Etc.
                </p>
            </div>
            <div class="row portfolio-controllers-container">
                <div class="portfolio-controllers wow fadeLeft" data-wow-duration="1s" data-wow-delay=".1s">
                    <button type="button" class="filter-btn active-work" data-filter="all">All</button>
                    <button type="button" class="filter-btn" data-filter=".graphics">Graphics</button>
                    <button type="button" class="filter-btn" data-filter=".web-design">Web Design & Dev</button>
                    <button type="button" class="filter-btn" data-filter=".ui-ux">Ui/UX</button>
                    <button type="button" class="filter-btn" data-filter=".motion-graphics">Motion</button>
                    <button type="button" class="filter-btn" data-filter=".data-entry">Data Entry</button>
                    <button type="button" class="filter-btn" data-filter=".youtube-marketing">Youtube</button>
                    <button type="button" class="filter-btn" data-filter=".digital-marketing">Digital</button>
                    <button type="button" class="filter-btn" data-filter=".video-editing">Video Editing</button>
                    <button type="button" class="filter-btn" data-filter=".apps-development">Apps</button>
                    <button type="button" class="filter-btn" data-filter=".animation">Animation</button>
                    <button type="button" class="filter-btn" data-filter=".others">Others</button>
                </div>
            </div>
        </div>
        <div class="portfolios">

            <?php $__currentLoopData = $ourPortfolios_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ourPortfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 portfolio <?php echo e($ourPortfolio->category_name); ?>">
                <figure class="portfolio-image">
                    <img src="<?php echo e(asset('uploads/ourPortfolio_photos')); ?>/<?php echo e($ourPortfolio->image); ?>" alt="" class="img-responsive">
                    <figcaption class="caption text-center">
                        <div class="caption-content">
                            <div class="my-custom-links w-100 h-100" data-vbtype="inline" data-maxwidth="800px"
                                href="#show-one">
                                <h4 class="portfolio-item-title text-center sub-title"><?php echo e($ourPortfolio->title); ?></h4>
                                <ul class="portfolio-link">
                                    <div id="show-one" style="display:none;">
                                        <img src="<?php echo e(asset('uploads/ourPortfolio_big_photos')); ?>/<?php echo e($ourPortfolio->big_image); ?>" alt="">
                                        <a target="_blank" href="<?php echo e($ourPortfolio->link); ?>"><?php echo e($ourPortfolio->button); ?></a>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </figcaption>
                </figure>
            </div>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <!-- ********************************
        ::: 4.0 contact
    ================================= -->
    </section>

    <?php echo $__env->make('frontend.partials.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontend.partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('footer_scripts'); ?>
    <script src="<?php echo e(asset('dashboard_app')); ?>/assets/js/portfolio-filter.min.js"></script>
    <script src="<?php echo e(asset('dashboard_app')); ?>/assets/js/venobox.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/frontend/portfolio.blade.php ENDPATH**/ ?>
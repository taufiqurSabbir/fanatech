

<link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/services.css">
<link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/contact.css">
<style>
.form-control {
    color: #dee3e9 !important;
}
</style>

<?php $__env->startSection('frontend_title'); ?>
<?php echo e(('Fexdvers | Services')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('frontend_content'); ?>

    <!-- ********************************
        main wrapper start here
    ================================= -->
    <main>

        <!-- ********************************
        ::: 2.0 service banner
    ================================= -->

    <section id="service-banner">
        <div class="banner-overlay">
            <div class="container">
                <h1 class="banner-title">Our Services</h2>
                    <div class="normal-btn py-3">
                        <a href="">GET STARTED <i class="fa-solid fa-angle-right"></i></a>
                    </div>
            </div>
        </div>
    </section>
    <!-- ********************************
    ::: 5.0 about
    ================================= -->

    <section id="about-section" class="pt-80">
        <div class="container">
            <div class="row gy-sm-5 gy-0">
                <div class="col-12">
                    <div class="row gy-4 align-items-center">
                        <div class="col-sm-6 col-md-3">
                            <div class="counter-card">
                                <div class="counter-card-img">
                                    <a href="#">
                                        <img src="<?php echo e(asset('dashboard_app')); ?>/assets/images/monitor-1.svg" alt="monitor-1.svg">
                                    </a>
                                </div>
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->seals) ? $about_info->seals : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> +</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Happy Clients</h4>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="counter-card">
                                <div class="counter-card-img">
                                    <a href="#">
                                        <img src="<?php echo e(asset('dashboard_app')); ?>/assets/images/link.svg" alt="link.svg">
                                    </a>
                                </div>
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->seals) ? $about_info->seals : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> y+</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Experience</h4>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="counter-card">
                                <div class="counter-card-img">
                                    <a href="#">
                                        <img src="<?php echo e(asset('dashboard_app')); ?>/assets/images/tech.svg" alt="tech.svg">
                                    </a>
                                </div>
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->seals) ? $about_info->seals : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> +</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Project Complete</h4>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="counter-card">
                                <div class="counter-card-img">
                                    <a href="#">
                                        <img src="<?php echo e(asset('dashboard_app')); ?>/assets/images/link.svg" alt="link.svg">
                                    </a>
                                </div>
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->seals) ? $about_info->seals : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> +</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Sales</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ********************************
       ::: 6.0 quality
    ================================= -->

    <section id="quality-section" class="pt-80">
        <div class="container">
            <div class="section-title">
                <h2>Our Services</h2>
                <p class="mt-2">
                    We provide you world-class service for you and your business with your satisfaction.
                </p>
            </div>
            <div class="swiper quality-swiper">
                <div class="swiper-wrapper">

                    <?php $__empty_1 = true; $__currentLoopData = $service_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <div class="swiper-slide">
                                <div class="quality-item">
                                    <div class="quality-icon">
                                        <img src="<?php echo e(asset('uploads/icon_photos')); ?>/<?php echo e($service->icon); ?>" alt="" style="width: 100px; height: 100px;">
                                    </div>
                                    <h3 class="quality-title"> <?php echo e(Str::limit($service->title , 120)); ?></h3>
                                    <p class="quality-text">
                                        <?php echo e(Str::limit($service->description , 400)); ?>

                                    </p>
                                </div>
                            </div>
                            
                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No Service
                    <?php endif; ?>   
                </div>
                
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>
    <!-- ********************************
    ::: 7.0 project
    ================================= -->

    <section id="service-deliver" class="pt-80">
        <div class="container">
            <div class="section-title">
                <h2>Why Choose fexdvers</h2>
                <p class="mt-2">
                    Fexdvers is a strong team for digital service provide. We are a world-wide digital IT service provider agency for develop your business.
                </p>
            </div>
            <div class="swiper deliver-swiper">
                <div class="swiper-wrapper">
                    <?php $__empty_1 = true; $__currentLoopData = $whychoosefexdvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whychoosefex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="swiper-slide">
                        <div class="deliver-card">
                            <div class="deliver-card-img">
                                <a href="#">
                                    <img src="<?php echo e(asset('uploads/whychoosefexdvers_photos')); ?>/<?php echo e($whychoosefex->icon); ?>" alt="monitor-1.svg">
                                </a>
                            </div>
                            <div class="deliver-card-body">
                                <h4 class="deliver-card-title"><?php echo e(Str::limit($whychoosefex->title , 120)); ?></h4>
                                <p class="deliver-card-text">
                                    <?php echo e(Str::limit($whychoosefex->description , 400)); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                   
                   

                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>
    <!-- ********************************
    ::: 9.0 testimonial
================================= -->
<?php echo $__env->make('frontend.partials.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/frontend/services.blade.php ENDPATH**/ ?>
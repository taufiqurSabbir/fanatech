

<?php $__env->startSection('page_title'); ?>
<?php echo e(('Fexdvers | About Add')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>


    <!-- ########## START: MAIN PANEL ########## -->
    <div class="br-mainpanel">
      <div class="br-pageheader pd-y-15 pd-l-20">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
          <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
          <span class="breadcrumb-item active">All Abouts</span>
        </nav>
      </div><!-- br-pageheader -->
      
      <div class="br-pagebody">
        <!-- start you own content here -->

       <div class="container-fluid">
         <div class="row">
           <div class="col-md-12">
              <h1 class = "text-center my-3">About Add Page</h1>

              <div class="btn-group mb-2" role="group" aria-label="Basic example">
                <a href = "<?php echo e(route('about.aboutViewAll')); ?>" type="button" class="btn btn-primary">All About</a>
              </div>

           </div>
         </div>
           <div class="row">
             
              <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       <h2>About Add</h2>
                    </div>
                    <div class="card-body">

                      <form method="post" action = "<?php echo e(route('about.store')); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                          <label>Happy Client</label>
                          <input type="number" class="form-control" placeholder="Happy Client" name = "happy_client" value = "<?php echo e(old('happy_client')); ?>">
                          <?php $__errorArgs = ['happy_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                          <label>Experience</label>
                          <input type="number" class="form-control" placeholder="Experience" name = "experience" value = "<?php echo e(old('experience')); ?>">
                          <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                          <label>Project Complete</label>
                          <input type="number" class="form-control" placeholder="Project Complete" name = "project_complete" value = "<?php echo e(old('project_complete')); ?>">
                          <?php $__errorArgs = ['project_complete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                          <label>Seals</label>
                          <input type="number" class="form-control" placeholder="Seals" name = "seals" value = "<?php echo e(old('seals')); ?>">
                          <?php $__errorArgs = ['seals'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                     
                        <div class="form-group">
                          <label>Description</label>
                          <textarea name="description" rows="8" class="form-control" placeholder="Description"
                          id="editor"><?php echo e(old('description')); ?></textarea>
                          <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Add About</button>
                      </form>

                    </div>
               </div>
              </div>

           </div>
       </div>

     </div><!-- sl-pagebody -->
   </div><!-- sl-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/admin/about/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('page_title'); ?>
<?php echo e(('Fexdvers | About View')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>

  <!-- ########## START: MAIN PANEL ########## -->
  <div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
      <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
        <span class="breadcrumb-item active">All Abouts</span>
      </nav>
    </div><!-- br-pageheader -->
    
    <div class="br-pagebody">
      <!-- start you own content here -->

       <div class="container-fluid">
         <div class="row">
           <div class="col-md-12">
              <h1 class = "text-center my-3">About View Page</h1>

              <div class="btn-group mb-2" role="group" aria-label="Basic example">
                <a href = "<?php echo e(route('about.index')); ?>" type="button" class="btn btn-success">Add About</a>
              </div>


           </div>
         </div>
           <div class="row">
              <div class="col-md-12">
                   <div class="card">
                       <div class="card-header">
                          <h2>About View</h2>
                          <hr>
                       </div>
                       <div class="card-body">
                          <?php if(session()->has('success_status')): ?>
                              <div class="alert alert-success alert-dismissible fade show" role="alert">
                                  <?php echo e(session()->get('success_status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                          <?php endif; ?>

                          <?php if(session()->has('delete_status')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(session()->get('delete_status')); ?>

                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                           <?php endif; ?>

                          <?php if(session()->has('update_status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session()->get('update_status')); ?>

                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                          <?php endif; ?>
                             <table class="table">
                               <thead>
                                 <tr>
                                   <th>ID No.</th>
                                   <th>Happy Client</th>
                                   <th>Exprience</th>
                                   <th>Project Complete</th>
                                   <th>Seals</th>
                                   <th>Description</th>
                                   <th>Action</th>
                                   
                                 </tr>
                               </thead>

                               <tbody>
                                 <?php $__empty_1 = true; $__currentLoopData = $aboutUs_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                 <tr>
                                   <td><?php echo e($about->id); ?></td>
                                   <td><?php echo e(Str::limit($about->happy_client , 10)); ?></td>
                                   <td><?php echo e(Str::limit($about->experience , 10)); ?></td>
                                   <td><?php echo e(Str::limit($about->project_complete , 10)); ?></td>
                                   <td><?php echo e(Str::limit($about->seals , 10)); ?></td>
                                   <td><?php echo e(Str::limit($about->description , 10)); ?></td>
                         
                                   <td>
                                     
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                      <a href = "<?php echo e(route('about.aboutEdit' , $about->id)); ?>" type="button" class="btn btn-primary">Edit</a>
                                      <a href = "<?php echo e(route('about.aboutDelete' , $about->id)); ?>" type="button" class="btn btn-danger">Delete</a>
                                    </div>

                                   </td>
                                 </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                   <tr>
                                     <td class = "text-danger text-center" colspan="50">No Data Available</td>
                                   </tr>
                               <?php endif; ?>

                               </tbody>
                             </table>

                       </div>
                   </div>
              </div>
           </div>
       </div>

     </div><!-- sl-pagebody -->
   </div><!-- sl-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/admin/about/show.blade.php ENDPATH**/ ?>
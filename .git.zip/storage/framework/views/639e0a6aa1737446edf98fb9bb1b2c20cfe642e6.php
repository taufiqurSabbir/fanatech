
<?php $__env->startSection('page_title'); ?>
  <?php echo e((' Fexdvers | Profile ')); ?>

  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('profile'); ?>
 active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard_content'); ?>
  <!-- ########## START: MAIN PANEL ########## -->
  <div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
      <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Dashboard</a>
        <span class="breadcrumb-item active">Profile Edit Page</span>
      </nav>
    </div><!-- br-pageheader -->
    <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
      <h4 class="tx-gray-800 mg-b-5">Profile Edit : <?php echo e(Auth::user()->name); ?></h4>
      <p class="mg-b-0">This is a Dynamic Place</p>
    </div>

    <div class="br-pagebody">
    <!-- start you own content here -->

    <div class="container-fluid">
         <div class="row">
           <div class="col-md-4">
             <div class="card">
                 <div class="card-header">
                    <h2>Name Change</h2>
                 </div>
                 <div class="card-body">

                   <form method="post" action = "<?php echo e(route('profile.nameupdate')); ?>">
                     <?php echo csrf_field(); ?>
                     <?php if(session()->has('name_change')): ?>
                       <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('name_change')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>
                     <?php if(session()->has('days_status')): ?>
                       <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('days_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>

                     <div class="form-group">
                       <label>Name Change</label>
                       <input type="text" class="form-control" placeholder="Name Change" name = "name" value="<?php echo e(Auth::user()->name); ?>">
                       <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class = "text-danger"><?php echo e($message); ?></span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <button type="submit" class="btn btn-primary">Name Change</button>
                   </form>

                 </div>
            </div>
           </div>

           <div class="col-md-4">
             <div class="card">
                 <div class="card-header">
                    <h2>Password Change</h2>
                 </div>
                 <div class="card-body">

                   <form method="post" action = "<?php echo e(route('password.edit')); ?>">
                     <?php echo csrf_field(); ?>
                     <?php if(session()->has('password_status')): ?>
                       <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('password_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>
                     <?php if(session()->has('pass_milenai_status')): ?>
                       <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('pass_milenai_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>
                     <?php if(session()->has('old_pass_status')): ?>
                       <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('old_pass_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>

                     <div class="form-group">
                       <label>Current Password</label>
                       <input type="password" class="form-control" placeholder="Old Password" name = "old_password" id="button_one">
                       <div class="form-group my-2">
                          <div class="form-check">
                            <input class="form-check-input ml-1" type="checkbox" value="" id="invalidCheck1" onclick="one_button()">
                            <label class="form-check-label text-primary ml-2" for="invalidCheck1">
                              Show Current Password
                            </label>
                          </div>
                        </div>

                       <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class = "text-danger"><?php echo e($message); ?></span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>

                     <div class="form-group">
                       <label>New Password</label>
                       <input type="password" class="form-control" placeholder="New Password" name = "password" id="button_two">
                       <div class="form-group my-2">
                          <div class="form-check">
                            <input class="form-check-input ml-1" type="checkbox" value="" id="invalidCheck2" onclick="two_button()">
                            <label class="form-check-label text-primary ml-2" for="invalidCheck2">
                              Show New Password
                            </label>
                          </div>
                        </div>
                       <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class = "text-danger"><?php echo e($message); ?></span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>

                     <div class="form-group">
                       <label>Confirm Password</label>
                       <input type="password" class="form-control" placeholder="Confirm Password" name = "password_confirmation" id="button_three">
                       <div class="form-group my-2">
                          <div class="form-check">
                            <input class="form-check-input ml-1" type="checkbox" value="" id="invalidCheck3" onclick="three_button()">
                            <label class="form-check-label text-primary ml-2" for="invalidCheck3">
                              Show Confirm Password
                            </label>
                          </div>
                        </div>
                       <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class = "text-danger"><?php echo e($message); ?></span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <button type="submit" class="btn btn-primary">Password Change</button>
                   </form>

                 </div>
            </div>
           </div>

           <div class="col-md-4">
             <div class="card">
                 <div class="card-header">
                    <h2>Profile Image Change</h2>
                 </div>
                 <div class="card-body">

                   <form method="post" action = "<?php echo e(route('profile.image')); ?>" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>

                     <?php if(session()->has('photo_status')): ?>
                       <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('photo_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>

                     <?php if(session()->has('photo_success')): ?>
                       <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <?php echo e(session()->get('photo_success')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>

                     <div class="form-group">
                       <label>Profile Image</label>
                       <input type="file" class="form-control" name = "profile_image">
                     </div>

                     <button type="submit" class="btn btn-primary">Profile Upload</button>
                   </form>

                 </div>
            </div>
           </div>
         </div>
       </div>

    </div><!-- br-pagebody -->

  </div><!-- br-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->


<?php $__env->stopSection(); ?>
<script>
function one_button() {
  var x = document.getElementById("button_one");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

<script>
function two_button() {
  var x = document.getElementById("button_two");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

<script>
function three_button() {
  var x = document.getElementById("button_three");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/profile/index.blade.php ENDPATH**/ ?>
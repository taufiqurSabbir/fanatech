    <!-- ********************************
    ::: 4.0 contact newsletter
    ================================= -->
    <section id="about-newsletter" class="pt-80 pb-5">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-9">
                    <h2 class="newsletter-title text-center">Subscribe Our Newsletter</h2>
                    <p class="py-3 text-center">
                        Join our subscribers list to get the latest news, updates and special offers delivered directly in your inbox.
                    </p>
                </div>

                
                <?php if(session()->has('success_status_store')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session()->get('success_status_store')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                <div class="col-sm-12 col-md-10 col-lg-7">
                    
                    <form action="<?php echo e(route('subscribeMail.store')); ?>" method="POST">
                    <div class="newsletter-field mt-3">
                            <?php echo csrf_field(); ?>
                            <input type="email" name="subeMail" id="email" placeholder="Enter Your E-mail">
                            <button class="newsletter-btn" type="submit" value="submit">Subscribe</button>
                            

                        </div>

                        <?php $__errorArgs = ['subeMail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class = "text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>

                        
                       
                </div>
            </div>
        </div>
    </section><?php /**PATH /home/fanatech/public_html/resources/views/frontend/partials/subscribe.blade.php ENDPATH**/ ?>
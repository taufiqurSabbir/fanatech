

<link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/contact.css">
<style>
.form-control {
    color: #dee3e9 !important;
}
</style>


<?php $__env->startSection('frontend_title'); ?>
<?php echo e(('Fexdvers | Contact Us')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('frontend_content'); ?>

    <!-- ********************************
        main wrapper start here
    ================================= -->
    <main>

     <!-- ********************************
        ::: 2.0 contact banner
    ================================= -->
    <section id="contact-banner">
        <div class="banner-overlay">
            <div class="container">
                <h1 class="banner-title">Contact With Us</h2>
                    <div class="normal-btn py-3">
                        <a href="">GET STARTED <i class="fa-solid fa-angle-right"></i></a>
                    </div>
            </div>
        </div>
    </section>

    <!-- ********************************
    ::: 3.0 contact us
    ================================= -->
    <section id="contact-us" class="pt-80">
        <div class="container">
            <div class="row justify-content-between gy-5 gy-md-0">
                <div class="col-md-5 col-sm-12">
                    <div class="section-title">
                        <h2 class="text-start" class="">Contact Us</h2>
                    </div>
                    <div class="contact-info">
                        <div class="contact-address mt-0">
                            <i class="fa-solid fa-location-dot"></i>
                            <h5>Address</h5>
                            <address>
                                Baipail, Bogabari, Soniya market, Ashulia, Saver, Dhaka-1349
                            </address>
                        </div>
                        <div class="contact-address">
                            <i class="fa-solid fa-phone"></i>
                            <h5>Call Now</h5>
                            <address>
                                <a href="tel:+8801628891457" style="color: #8c8c8c;">+8801628891457</a> <br>
                                <a href="tel:+8801612355769" style="color: #8c8c8c;">+8801612355769</a>
                            </address>
                        </div>
                        <div class="contact-address">
                            <i class="fa-solid fa-envelope"></i>
                            <h5>E-mail</h5>
                            <address>
                                <a href="mailto:fexdvers@gmail.com" class="contact-text" style="color: #8c8c8c !important;">fexdvers@gmail.com</a>
                            </address>
                        </div>
                        <div class="contact-address">
                            <i class="fa-solid fa-earth-asia"></i>
                            <h5>Website</h5>
                            <address>
                                <a href="https://www.fexdvers.com/" target="_blank" style="color: #8c8c8c !important;">www.fexdvers.com</a>
                            </address>

                            <h3></h3>
                            

                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="contact-form">
                        <div class="section-title">
                            <h2>Order Now</h2>
                            <p class="mt-2">
                                We're always happy to discuss your project with you and put together a free proposal, just fill out the form below or give us a call to get start.
                            </p>
                        </div>
                        <form class="row gy-5" action="<?php echo e(route('contact.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <?php if(session()->has('success_status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session()->get('success_status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>

                            <div class="col-md-6">
                                <input type="text" name="buyer_name" class="form-control" id="input-field"
                                    placeholder="Your Name">
                                    <?php $__errorArgs = ['buyer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class = "text-danger"><?php echo e($message); ?></span>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  

                            </div>
                            <div class="col-md-6">
                                <input type="email" name="buyer_email" class="form-control" id="input-field"
                                    placeholder="Your E-mail">
                                    <?php $__errorArgs = ['buyer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class = "text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="col-md-6">
                                <input type="text" name="buyer_country" class="form-control" id="input-field"
                                    placeholder="Your Country">
                                    <?php $__errorArgs = ['buyer_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class = "text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="col-md-6">
                                <input type="number" name="buyer_whatsapp_number" class="form-control" id="input-field"
                                    placeholder="WhatsApp/Phone">
                                    <?php $__errorArgs = ['buyer_whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class = "text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="buyer_services" class="form-control" id="input-field"
                                    placeholder="Your Service(s)">
                                    <?php $__errorArgs = ['buyer_services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class = "text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="buyer_budget" class="form-control" id="input-field"
                                    placeholder="Your Budget">
                                    <?php $__errorArgs = ['buyer_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class = "text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                <textarea name="buyer_message" class="form-control" placeholder="Your Message"
                                    style="height: 60px"></textarea>
                                    <?php $__errorArgs = ['buyer_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class = "text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="gridCheck">
                                    <label class="form-check-label" for="gridCheck">
                                        I Agree To The Terms & Conditions Of Business Name
                                    </label>
                                </div>
                            </div>
                            <div class="d-grid mx-auto col-12">
                                <button type="submit" value="submit" class="submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('frontend.partials.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontend.partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ********************************
    ::: 5.0 contact
    ================================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/frontend/contact.blade.php ENDPATH**/ ?>
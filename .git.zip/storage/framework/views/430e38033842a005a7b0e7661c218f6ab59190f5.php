<?php $__env->startSection('page_title'); ?>
<?php echo e('Fexdvers | Home'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>

  <!-- ########## START: MAIN PANEL ########## -->
  <div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
      <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
        <span class="breadcrumb-item active">All Users</span>
      </nav>
    </div><!-- br-pageheader -->
    <div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
      <h4 class="tx-gray-800 mg-b-5">Dashboard Page ( All Users : )</h4>
      <?php if(Auth::user()->role == 1): ?>
      <p class="mg-b-0">You Are a Admin.</p>
      <?php else: ?>
      <p class="mg-b-0">You Are a Modaretor.</p>
      <?php endif; ?>
    </div>

    <div class="br-pagebody">
      <!-- start you own content here -->

      <div class="col-lg-12 mb-3">
        <?php if(session()->has('success_status')): ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
           <?php echo e(session()->get('success_status')); ?>

           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>
       <?php endif; ?>

     


      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <div class="table-wrapper">
              <table id="datatable1" class="table display responsive nowrap">
                <thead>
                  <tr>
                    <th class="wd-15p">User Name</th>
                    <th class="wd-15p">ID No.</th>
                    <th class="wd-20p">User Email</th>
                    <th class="wd-15p">Created Date</th>
                    <th class="wd-10p">Updated Date</th>
                  </tr>
                </thead>
                <tbody>

                </tbody>
              </table>
            </div><!-- table-wrapper -->

          </div>
        </div>
      </div>
    </div><!-- br-pagebody -->
  </div><!-- br-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/home.blade.php ENDPATH**/ ?>
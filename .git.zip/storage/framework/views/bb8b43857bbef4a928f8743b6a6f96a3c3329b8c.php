

<?php $__env->startSection('page_title'); ?>
<?php echo e(('Fexdvers | Customer Contact')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contactInfo'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>


  <!-- ########## START: MAIN PANEL ########## -->
  <div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
      <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
        <span class="breadcrumb-item active">All Customers Contacts</span>
      </nav>
    </div><!-- br-pageheader -->
    
    <div class="br-pagebody">
      <!-- start you own content here -->

      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <h1 class = "text-center my-3">Customer Contacts</h1>
          </div>
        </div>
          <div class="row">
             <div class="col-md-12">
                  <div class="card">
                      <div class="card-header">
                         <h2>Contact View</h2>
                         <hr>
                      </div>
                      <div class="card-body">
                         <?php if(session()->has('success_status')): ?>
                             <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                 <?php echo e(session()->get('success_status')); ?>

                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                               </button>
                             </div>
                         <?php endif; ?>

                         <?php if(session()->has('delete_status')): ?>
                           <div class="alert alert-danger alert-dismissible fade show" role="alert">
                               <?php echo e(session()->get('delete_status')); ?>

                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                             </button>
                           </div>
                          <?php endif; ?>

                         <?php if(session()->has('udpate_status')): ?>
                           <div class="alert alert-success alert-dismissible fade show" role="alert">
                               <?php echo e(session()->get('udpate_status')); ?>

                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                             </button>
                           </div>
                         <?php endif; ?>

                        
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>SL No.</th>
                                  <th>Customer Name</th>
                                  <th>Email</th>
                                  <th>What's app Number</th>
                                  <th>Services</th>
                                  <th>Country</th>
                                 
                                  <th>Message</th>
                                  <th>Action</th>
                                </tr>
                              </thead>

                    
                              <tbody>
                                  <?php $__empty_1 = true; $__currentLoopData = $contactInfo_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                  <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td><?php echo e(Str::limit($contactInfo->name , 10)); ?></td>
                                    <td><?php echo e($contactInfo->email); ?></td>
                                    <td><?php echo e($contactInfo->whatsapp_number); ?></td>
                                    <td><?php echo e($contactInfo->services); ?></td>
                                    <td><?php echo e($contactInfo->country); ?></td>
                                   
                                    <td><?php echo e(Str::limit($contactInfo->message , 10)); ?></td>

                                    <td>
                                      <div class="btn-group" role="group" aria-label="Basic example">

                                        
                                        <form action="<?php echo e(route('contactInfo.destroy' , $contactInfo->id)); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('DELETE'); ?>
                                          <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                      </div>
                                    </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                      <td class = "text-danger text-center" colspan="50">No Data Available</td>
                                    </tr>
                                <?php endif; ?>
  
                              </tbody>
                   
                            </table>

                      </div>
                  </div>
             </div>
          </div>
      </div>
    </div><!-- br-pagebody -->
  </div><!-- br-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/admin/customerContact/show.blade.php ENDPATH**/ ?>
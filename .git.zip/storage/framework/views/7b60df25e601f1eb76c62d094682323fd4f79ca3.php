

<?php $__env->startSection('page_title'); ?>
<?php echo e(('Fexdvers | Subcribemail Add')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('subscribe'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>


  <!-- ########## START: MAIN PANEL ########## -->
  <div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
      <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
        <span class="breadcrumb-item active">All Subcribemails</span>
      </nav>
    </div><!-- br-pageheader -->
    
    <div class="br-pagebody">
      <!-- start you own content here -->

      <div class="container">
        <div class="row">
          <div class="col-md-12">
              <h1 class = "text-center my-3">Subcribemail Add Page</h1>
              </div>
          </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                 <div class="card">
                     <div class="card-header">
                        <h2>Subscribemail View </h2>
                     </div>
                     <div class="card-body">
                    
                        <?php if(session()->has('delete_status')): ?>
                          <div class="alert alert-danger alert-dismissible fade show" role="alert">
                              <?php echo e(session()->get('delete_status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                         <?php endif; ?>

                           <table class="table">
                             <thead>
                               <tr>
                                 <th>SL No.</th>
                                 <th>Subscribemail </th>
                                 <th>Action</th>
                               </tr>
                             </thead>

                             <tbody>
                              <?php $__empty_1 = true; $__currentLoopData = $subscribeMails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscribemail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                               <tr>
                                 <td><?php echo e($loop->index + 1); ?></td>
                                 
                                 <td><?php echo e(Str::limit($subscribemail->subeMail , 25)); ?></td>
                                
                                 <td>

                                   <a href = "<?php echo e(route('subscribeMail.mail',$subscribemail->id)); ?>" type="button" class="btn btn-primary">Mail Sent</a>
                                   
                                   <div class="btn-group" role="group" aria-label="Basic example">
                                     <form action="<?php echo e(route('subscribeMail.destroy',$subscribemail->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                   </div>

                                 </td>
                               </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                 <tr>
                                   <td class = "text-danger text-center" colspan="50">No Data Available</td>
                                 </tr>
                              <?php endif; ?>

                             </tbody>
                           </table>

                     </div>
                 </div>
            </div>
         </div>

        
       
      </div>
    </div><!-- br-pagebody -->
  </div><!-- br-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/admin/subscribeMail/show.blade.php ENDPATH**/ ?>
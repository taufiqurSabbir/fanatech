<section id="contact-section" class="pt-80">
    <div class="container">
        <div class="row justify-content-between gy-4 gy-md-0">
            <div class="col-md-5 col-sm-12">
                <div class="contact-info">
                    <div class="section-title">
                        <h2 class="left-title">Get In Touch</h2>
                    </div>
                    <div class="contact-content">
                        <p class="contact-text">
                            We are a World-Wide Digital IT Service Provider Agency. We provide you world-class service for you and your business.
                            Let's start an amazing project.
                        </p>
                        <div class="contact-address d-flex align-items-center">
                            <i class="fa-solid fa-envelope"></i>
                            <a href="mailto:fexdverse@gmail.com" style="color: #8c8c8c !important;">fexdvers@gmail.com</p>
                        </div>
                        <div class="contact-address d-flex align-items-center">
                            <i class="phone fa-solid fa-phone"></i>
                            <a href="tel:+8801628891457" style="color: #8c8c8c !important;">+8801628891457</a>
                        </div>

                        <div class="normal-icon d-flex align-items-center">
                            <a href="https://www.facebook.com/fexdvers" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="https://www.instagram.com/fexdvers" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                            <a href="https://www.linkedin.com/fexdvers" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
                            <a href="https://www.behance.net/fexdvers" target="_blank"><i class="fa-brands fa-behance"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="contact-form">
                    <div class="section-title">
                        <h2 class="left-title">Have Any Question? Drop A Lile.</h2>
                    </div>

                    <form class="row g-3" action="<?php echo e(route('contactInfo.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <?php if(session()->has('success_status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session()->get('success_status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>


                        <div class="col-md-6">
                            <input type="text" name="name" class="form-control" id="input-field"
                                placeholder="Your Name">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class = "text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                        </div>
                        
                        <div class="col-md-6">
                            <input type="email" name="email" class="form-control" id="input-field"
                                placeholder="Your E-mail">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class = "text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="country" class="form-control" id="input-field"
                                placeholder="Your Country">
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class = "text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <input type="number" name="whatsapp_number" class="form-control" id="input-field"
                                placeholder="WhatsApp/Phone">
                                <?php $__errorArgs = ['whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class = "text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-12">
                            <input type="text" name="services" class="form-control" id="input-field"
                                placeholder="Your Service(s)">
                                <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class = "text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="col-md-12">
                            <textarea name="message" class="form-control" placeholder="Your Message"
                                style="height: 60px"></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class = "text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="gridCheck">
                                <label class="form-check-label" for="gridCheck">
                                    I Agree To The Terms & Conditions Of Business Name
                                </label>
                            </div>
                        </div>
                        <div class="d-grid mx-auto col-12">
                            <button type="submit" value="submit" class="submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/fanatech/public_html/resources/views/frontend/partials/contact.blade.php ENDPATH**/ ?>
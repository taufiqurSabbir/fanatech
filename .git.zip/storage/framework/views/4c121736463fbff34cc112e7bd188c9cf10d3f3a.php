

<?php $__env->startSection('page_title'); ?>
<?php echo e(('Fexdvers | Business-Brand')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('Multiple Business Brand'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>

  <!-- ########## START: MAIN PANEL ########## -->
  <div class="br-mainpanel">
    <div class="br-pageheader pd-y-15 pd-l-20">
      <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
        <span class="breadcrumb-item active">Add Notice</span>
      </nav>
    </div><!-- br-pageheader -->
    
    <div class="br-pagebody">
      <!-- start you own content here -->

       <div class="container-fluid">
         <div class="row">
           <div class="col-md-12">
              <h1 class = "text-center my-3">Multiple Business Brand Add Page</h1>
           </div>
         </div>
           <div class="row">

            <div class="col-md-8">
              <div class="card">
                  <div class="card-header">
                     <h2>Multiple Business Brand View</h2>
                     <hr>
                  </div>
                  <div class="card-body">
                     <?php if(session()->has('success_status')): ?>
                         <div class="alert alert-success alert-dismissible fade show" role="alert">
                             <?php echo e(session()->get('success_status')); ?>

                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                           </button>
                         </div>
                     <?php endif; ?>

                     <?php if(session()->has('delete_status')): ?>
                       <div class="alert alert-danger alert-dismissible fade show" role="alert">
                           <?php echo e(session()->get('delete_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                      <?php endif; ?>

                     <?php if(session()->has('update_status')): ?>
                       <div class="alert alert-success alert-dismissible fade show" role="alert">
                           <?php echo e(session()->get('update_status')); ?>

                         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                     <?php endif; ?>

                    
                        <table class="table">
                          <thead>
                            <tr>
                              <th>SL No.</th>
                              <th>Brand Link</th>
                              <th>Brand Logo</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>


                            <?php $__empty_1 = true; $__currentLoopData = $multipleBusinessBrands_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multipleBusinessBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                              <td><?php echo e($loop->index + 1); ?></td>

                            
                              <td><?php echo e(Str::limit($multipleBusinessBrand->brand_link , 30)); ?></td>

                              <td>
                                <img src="<?php echo e(asset('uploads/multipleBusinessBrand_photos')); ?>/<?php echo e($multipleBusinessBrand->brand_logo); ?>" alt="" width="60">
                              </td>

                             
                             
                              <td>
                                
                                <div class="btn-group" role="group" aria-label="Basic example">
                                  
                                  <a href = "<?php echo e(route('multipleBusinessBrand.edit' , $multipleBusinessBrand->id)); ?>" class="btn btn-primary btn-sm">Edit</a>

                                  <form action="<?php echo e(route('multipleBusinessBrand.destroy',$multipleBusinessBrand->id)); ?>" method="POST">
                                     <?php echo csrf_field(); ?>
                                     <?php echo method_field('DELETE'); ?>
                                     <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                 </form>
                                </div>

                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <tr>
                                <td class = "text-danger text-center" colspan="50">No Data Available</td>
                              </tr>
                          <?php endif; ?>

                          </tbody>
                        </table>

                  </div>
              </div>
            </div>
             
              <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                       <h2>Multiple Business Brand Add</h2>
                    </div>
                    <div class="card-body">

                      <form method="post" action = "<?php echo e(route('multipleBusinessBrand.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                          <label>Brand Link</label>
                          <input type="text" class="form-control" placeholder="Multiple Business Brand Link" name = "brand_link" value = "<?php echo e(old('brand_link')); ?>">
                          <?php $__errorArgs = ['brand_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                          <label>Brand Logo</label>
                          <input type="file" class="form-control" name="brand_logo">
                          <?php $__errorArgs = ['brand_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class = "text-danger"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">SUBMIT</button>
                      </form>

                    </div>
               </div>
              </div>

           </div>
       </div>

     </div><!-- sl-pagebody -->
   </div><!-- sl-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/admin/multipleBusinessBrand/index.blade.php ENDPATH**/ ?>
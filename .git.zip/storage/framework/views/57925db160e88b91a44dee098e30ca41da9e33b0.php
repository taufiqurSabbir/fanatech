<link rel="stylesheet" href="<?php echo e(asset('dashboard_app')); ?>/assets/css/contact.css">
<style>
.form-control {
    color: #dee3e9 !important;
}
</style>


<?php $__env->startSection('frontend_content'); ?>
    <!-- ********************************
        main wrapper start here
    ================================= -->
    <main>

        <!-- ********************************
        ::: 4.0 banner
    ================================= -->

        <section id="banner-section" class="pt-80">
            <div class="container">
                <div class="row gy-4 gy-md-0">
                    <div class="col-md-6 col-sm-12 align-items-center">
                        <div class="banner-welcome">

                            
                            <h1 class="banner-title" style="font-size: 36px !important;">
                                <?php if(isset($banner_info->title)): ?>
                                    <?php echo e(Str::limit($banner_info->title , 120)); ?>    
                                <?php endif; ?>
                            </h1>
                            <p class="banner-text py-4">
                                <?php if(isset($banner_info->description)): ?>
                                    <?php echo e(Str::limit($banner_info->description , 300)); ?>    
                                <?php endif; ?>
                            </p>
                            <div class="normal-btn py-3">
                                <?php if(isset($banner_info->button)): ?>
                                    <a href="<?php echo e($banner_info->link); ?>"><?php echo e(Str::limit($banner_info->button , 10)); ?><i class="fa-solid fa-angle-right"></i></a>
                                <?php endif; ?>

                            </div>
                            <div class="normal-icon d-flex align-items-center pt-3">
                                <p class="me-3">Follow Us--</p>
                                <div>
                                    <a href="https://www.facebook.com/fexdvers" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href="https://www.instagram.com/fexdvers" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                                    <a href="https://www.linkedin.com/fexdvers" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
                                    <a href="https://www.behance.net/fexdvers" target="_blank"><i class="fa-brands fa-behance"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 align-items-center">
                        <div class="banner-img">
                            <img class="img-fluid w-auto mx-auto" src="<?php echo e(asset('dashboard_app')); ?>/assets/images/banner-img.png"
                                alt="banner-img.png">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 5.0 about
    ================================= -->

    <section id="about-section" class="pt-80">
        <div class="container">
            <div class="row gy-sm-5 gy-0">
                <div class="col-md-6 col-sm-12">
                    <div class="about-text">
                        <div class="section-title">
                            <h2 class="left-title">About Our fexdvers</h2>
                        </div>
                      
                        <p class="about-dtls">
                            <?php if(isset($about_info->description)): ?>
                                 <?php echo Str::limit($about_info->description , 330); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="row gy-4 align-items-center">
                        <div class="col-sm-6">
                            <div class="counter-card">
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->happy_client) ? $about_info->happy_client : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> +</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Happy Clients</h4>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="counter-card">
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->experience) ? $about_info->experience : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> y+</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Experience</h4>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="counter-card">
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->project_complete) ? $about_info->project_complete : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> +</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Project Complete</h4>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="counter-card">
                                <div class="d-flex align-items-center justify-content-center">
                                    <h2 class="counter-item" data-num="<?php echo e(isset($about_info->seals) ? $about_info->seals : 0); ?>" data-speed="10"></h2>
                                    <span class="plus"> +</span>
                                </div>
                                <h4 class="my-lg-3 my-sm-2 my-md-2">Sales</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

        <!-- ********************************
        ::: 6.0 quality
    ================================= -->

        <section id="quality-section" class="pt-80">
            <div class="container">
                <div class="section-title">
                    <h2>Quality Services Showed</h2>
                </div>
                <div class="swiper quality-swiper">
                    <div class="swiper-wrapper">

                        <?php $__empty_1 = true; $__currentLoopData = $service_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <div class="swiper-slide">
                                <div class="quality-item">
                                    <div class="quality-icon">
                                        <img src="<?php echo e(asset('uploads/icon_photos')); ?>/<?php echo e($service->icon); ?>" alt="" style="width: 80px; height: 80px;">
                                    </div>
                                    <h3 class="quality-title"> <?php echo e(Str::limit($service->title , 120)); ?></h3>
                                    <p class="quality-text">
                                        <?php echo e(Str::limit($service->description , 400)); ?>

                                    </p>
                                </div>
                            </div>
                            
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            No Service
                        <?php endif; ?>


                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 7.0 project
    ================================= -->

        <section id="project-section" class="pt-80">
            <div class="container">
                <div class="section-title">
                    <h2>Project highlights</h2>
                </div>
                <div class="swiper project-swiper">
                    <div class="swiper-wrapper">

                        <?php $__empty_1 = true; $__currentLoopData = $project_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            
                            <div class="swiper-slide">
                                <div class="project-card">
                                    <div class="project-card-img">
                                        <a href="<?php echo e(route('portfolio-details-page', $project->id)); ?>">
                                            <img src="<?php echo e(asset('uploads/portfolio_photos')); ?>/<?php echo e($project->image); ?>" alt="project-img.jpeg">
                                        </a>
                                    </div>
                                    <div class="project-card-body">
                                        <a href="<?php echo e(route('portfolio-details-page', $project->id)); ?>">
                                            <h3 class="project-card-title"><?php echo e(Str::limit($project->title , 30)); ?></h3>
                                        </a>
                                        <p class="project-card-text">
                                            <?php echo e(Str::limit($project->short_details , 80)); ?>

                                        </p>
                                        <span class="project-card-btn">
                                            <a href="<?php echo e(route('portfolio-details-page', $project->id)); ?>">
                                                Read More >>
                                            </a>
                                        </span>
                                    </div>
                                    <div class="project-card-footer">
                                        <p class="text-muted project-footer-text">Date:- <small><?php echo e($project->date); ?></small></p>
                                    </div>
                                </div>
                            </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            No Project Available
                        <?php endif; ?>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 8.0 clients
    ================================= -->

        <section id="clients-section" class="pt-80">
            <div class="container">
                <div class="section-title">
                    <h2>Our Multiple Business</h2>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="swiper clients-swiper">

                            <div class="swiper-wrapper">

                                <?php $__empty_1 = true; $__currentLoopData = $brand_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    
                                    <div class="swiper-slide">
                                        <img src="<?php echo e(asset('uploads/multipleBusinessBrand_photos')); ?>/<?php echo e($brand->brand_logo); ?>" alt="clients-img-1.png">
                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  No Colabortion   
                                <?php endif; ?>

                               
                               
                            </div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 9.0 team 
    ================================= -->

        <section id="team-section" class="pt-80">
            <div class="container">
                <div class="section-title">
                    <h2>Our Members</h2>
                </div>
                <div class="swiper team-swiper">
                    <div class="swiper-wrapper">
                        

                        <?php $__empty_1 = true; $__currentLoopData = $teamMembers_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <div class="swiper-slide">

                                <div class="team-member">
                                    <div class="team-member-img">
                                        <a href="<?php echo e(route('team-details-page', $teamMember->id)); ?>">
                                            <img src="<?php echo e(asset('uploads/teamMember_photos')); ?>/<?php echo e($teamMember->image); ?>" alt="team-member-img-1.png">
                                        </a>
                                        <div class="team-member-overlay normal-icon">
                                            <a href="<?php echo e($teamMember->fb_one); ?>"><i class="fa-brands fa-facebook-f one"></i></a>
                                            <a href="<?php echo e($teamMember->ins_two); ?>"><i class="fa-brands fa-instagram three"></i></a>
                                            <a href="<?php echo e($teamMember->ln_three); ?>"><i class="fa-brands fa-linkedin-in four"></i></a>
                                            <a href="<?php echo e($teamMember->de_four); ?>"><i class="fa-brands fa-behance five"></i></a>
                                        </div>
                                    </div>
                                    <div class="team-member-info">
                                        <a href="<?php echo e(route('team-details-page', $teamMember->id)); ?>">
                                            <h5 class="team-member-title my-1"><?php echo e(Str::limit($teamMember->name , 40)); ?></h5>
                                        </a>
                                        <p>
                                            <?php echo e(Str::limit($teamMember->expert , 30)); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                          No Team Mate
                            
                        <?php endif; ?>
                       
                       

                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 10.0 testimonial
    ================================= -->

        <section id="testi-section" class="pt-80">
            <div class="container">
                <div class="section-title">
                    <h2>What Our Clients Say</h2>
                </div>
                <div class="swiper testi-swiper">
                    <div class="swiper-wrapper">

                        <?php $__empty_1 = true; $__currentLoopData = $testimonials_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonials): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <div class="swiper-slide">
                            <div class="testi-client">
                                <div class="row align-items-center gy-5">
                                    <div class="col-md-5 col-sm-12">
                                        <div class="client-img">
                                            <img src="<?php echo e(asset('uploads/testimonial_photos')); ?>/<?php echo e($testimonials->image); ?>" alt="testi-img-1.png">
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-sm-12">
                                        <div class="client-text">
                                            <h4 class="client-name"><?php echo e(Str::limit($testimonials->name , 100)); ?> - <span><?php echo e(Str::limit($testimonials->title , 100)); ?></span></h4>
                                            <h2 class="service-type"><?php echo e(Str::limit($testimonials->position , 60)); ?></h2>
                                            <p class="serviec-text">
                                                <?php echo Str::limit($testimonials->description , 300); ?>

                                            </p>
                                            <div class="rating">
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                          No Comments
                            
                        <?php endif; ?>
                        
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </section>

        <!-- ********************************
        ::: 11.0 contact
    ================================= -->

    <?php echo $__env->make('frontend.partials.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fanatech/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>